<?PHP
/*
Plugin Name: Woocommerce Stock Display
Plugin URI: https://finalrope.com/final-plugins/woocommerce-stock-display
Description: Woocommerce Stock Display plugin would display a nice looking stocks on single product pages for simple and variation products.
Version: 1.0.0
Author: FinalRope, Ravikas kamboj
Author URI: http://finalrope.com
Text Domain: woocommerce_stock_display

 * Copyright FinalRope Plugins
 *
 *		This file is part of Woocommerce Stock Display,
 *		a plugin for WordPress.
 *
 *		Woocommerce Stock Display is free software:
 *		You can redistribute it and/or modify it under the terms of the
 *		GNU General Public License as published by the Free Software
 *		Foundation, either version 3 of the License, or (at your option)
 *		any later version.
 *
 *		Woocommerce Stock Display is distributed in the hope that
 *		it will be useful, but WITHOUT ANY WARRANTY; without even the
 *		implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *		PURPOSE. See the GNU General Public License for more details.
 *
 *		You should have received a copy of the GNU General Public License
 *		along with WordPress. If not, see <http://www.gnu.org/licenses/>.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Class WSD_stockdisplay.
 *
 * Main FinalRope class initializes the plugin.
 *
 * @class		WSD_stockdisplay
 * @version		1.0.0
 * @author		Ravikas kamboj
 */
class WSD_stockdisplay {


	/**
	 * Plugin version.
	 *
	 * @since 1.0.0
	 * @var string $version Plugin version number.
	 */
	public $version = '1.0.0';


	/**
	 * Plugin file.
	 *
	 * @since 1.0.0
	 * @var string $file Plugin file path.
	 */
	public $file = __FILE__;


	/**
	 * Instance of WSD_stockdisplay.
	 *
	 * @since 1.0.0
	 * @access private
	 * @var object $instance The instance of WSD_stockdisplay.
	 */
	private static $instance;


	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		if ( ! function_exists( 'is_plugin_active_for_network' ) ) :
			require_once( ABSPATH . '/wp-admin/includes/plugin.php' );
		endif;

		// Check if WooCommerce is active
		if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) :
			if ( ! is_plugin_active_for_network( 'woocommerce/woocommerce.php' ) ) :
				return;
			endif;
		endif;

		$this->init();

	}


	/**
	 * Instance.
	 *
	 * An global instance of the class. Used to retrieve the instance
	 * to use on other files/plugins/themes.
	 *
	 * @since 1.0.0
	 * @return object Instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$instance ) ) :
			self::$instance = new self();
		endif;

		return self::$instance;

	}


	/**
	 * Init.
	 *
	 * Initialize plugin parts.
	 *
	 * @since 1.0.0
	 */
	public function init() {

		if ( is_admin() ) :

			/**
			 * Admin panel
			 */
			require_once plugin_dir_path( __FILE__ ) . 'admin/WSD-finalrope-admin-class.php';
			$this->admin = new WSD_finalropeAdmin();

			/**
			 * Bulk edit Admin panel
			 */
			require_once plugin_dir_path( __FILE__ ) . 'admin/WSD-finalrope-bulk-edit-class.php';
			$this->bulk_edit = new WSD_finalropeAdminBulkEdit();

			/**
			 * Quick edit Admin panel
			 */
			require_once plugin_dir_path( __FILE__ ) . 'admin/WSD-finalrope-quick-edit-class.php';
			$this->quick_edit = new WSD_finalropeAdminQuickEdit();

		endif;

		// Add the display stock
		add_action( 'woocommerce_single_product_summary', array( $this, 'WSD_stockShow' ), 45 );

		// Enqueue style
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_style' ) );

	}


	/**
	 * Display stock.
	 *
	 * Add the display stock to product page.
	 *
	 * @since 1.0.0
	 *
	 * @global WC_Product_Variable $product Get product object.
	 */
	public function WSD_stockShow() {

		global $product;
		$displayWSD_stockShow = get_post_meta( $product->id, 'WSD_stockShow', true );

		if ( 'no' == $displayWSD_stockShow || empty ( $displayWSD_stockShow ) ) :
			return;
		endif;

		?>
		<h3 class='display-stock-title'><?php _e( 'Available Stocks', 'WSD_woocommerceStockShow' ); ?></h3>
		<div class='display-stock'><?php

			if ( 'variable' == $product->product_type ) :

				// Loop variations
				$available_variations = $product->get_available_variations();
				foreach ( $available_variations as $variation ) :

					$max_stock 	= $product->get_total_stock();
					$var 		= wc_get_product( $variation['variation_id'] );

					if ( true == $var->variation_has_stock ) :

						// Get variation name
						$WSD_variationName = $this->WSD_variationName( $variation['attributes'] );

						// Get an display stock_bar
						$this->WSD_getDisplayStockBar( $variation['variation_id'], $max_stock, $WSD_variationName );

					endif;

				endforeach;

			endif;

			if ( 'simple' == $product->product_type ) :

				$this->WSD_getDisplayStockBar( $product->id, $product->get_total_stock(), $product->get_formatted_name() );

			endif;

		?></div><?php

	}


	/**
	 * Stock stock_bar.
	 *
	 * Get an single stock stock_bar.
	 *
	 * @since 1.0.0
	 *
	 * @param int		$product_id 		ID of the product.
	 * @param int 		$max_stock 			Stock quantity of the variation with the most stock.
	 * @param string 	$WSD_variationName 	Name of the variation.
	 */
	public function WSD_getDisplayStockBar( $product_id, $max_stock, $WSD_variationName ) {

		$stock 		= get_post_meta( $product_id, '_stock', true );
		if ($max_stock>0) {
			$percentage = round( $stock / $max_stock * 100 );
		} else {
			$percentage = 0;
		}
		?><div class='stock_bar-wrap'>

			<div class='variation-name'><?php echo $WSD_variationName; ?></div>

			<div class='stock_bar'>
				<div class='stock_fill<?php if ( 0 == $stock ) { echo ' out-of-stock'; } ?>' style='width: <?php echo $percentage; ?>%;'><?php echo (int) $stock; ?></div>
			</div>

		</div><?php

	}


	/**
	 * Variation name.
	 *
	 * Get the variation name based on the attributes.
	 *
	 * @since 1.0.0
	 *
	 * @param 	array 	$attributes 	All the attributes of the variation
	 * @return 	string 					Variation name based on attributes.
	 */
	public function WSD_variationName( $attributes ) {

		$WSD_variationName = '';

		foreach ( $attributes as $attr => $value ) :

			if ( term_exists( $value, str_replace( 'attribute_', '', $attr ) ) ) :

				$term = get_term_by( 'slug', $value, str_replace( 'attribute_', '', $attr ) );
				if ( isset( $term->name ) ) :
					$WSD_variationName .= $term->name . ', ';

				endif;

			else :

				$WSD_variationName .= $value . ', ';

			endif;

		endforeach;

		return rtrim( $WSD_variationName, ', ' );

	}


	/**
	 * Enqueue style.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_style() {
		wp_enqueue_style( 'WSD_woocommerceStockShow', plugins_url( 'assets/css/WSD_woocommerceStockShow.css', __FILE__ ) );
	}

}


/**
 * The main function responsible for returning the WSD_stockdisplay object.
 *
 * Use this function like you would a global variable, except without needing to declare the global.
 *
 * Example: <?php WSD_stockdisplay()->method_name(); ?>
 *
 * @since 1.0.0
 *
 * @return object WSD_stockdisplay class object.
 */
if ( ! function_exists( 'WSD_stockdisplay' ) ) :

 	function WSD_stockdisplay() {
		return WSD_stockdisplay::instance();
	}

endif;

WSD_stockdisplay();