=== WooCommerce Display Stock ===
Contributors: finalrope, ravikas kamboj
Tags: woocommerce, woocommerce stock, woocommerce inventory, stock, woocommerce display, woocommerce stock, woocommerce display stock
Requires at least: 3.6
Tested up to: 4.5.2
Stable tag: 1.0.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

WooCommerce Display Stocks adds a stock below the add-to-cart button with the available variations and the number in stock.

== Description ==
WooCommerce Display Stocks adds a stock below the add-to-cart button with the available variations and the number in stock.

**Translations, feature requests, ratings and donations are welcome and appreciated!**

This plugin is managed on <a href="https://github.com/finalrope/woocommerce-stock-display">GitHub</a>.

== Installation ==

1. Upload the folder `WSD_woocommerceStockShow` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Edit a WooCommerce product and enable the 'Display stock' option in the Product Data panel.

== Frequently Asked Questions ==

= Can I change the colors of the stock_bar via the admin? =

Currently the only way to change the stock_bar colors is by overriding the CSS.


== Upgrade Notice ==

None.

== Screenshots ==

1. Enable from admin
2. Display on single product
3. Variable product settings from admin
4. Simple product settings from admin

== Changelog ==

= 1.0.0 =
* Initial release
